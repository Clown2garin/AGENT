﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProektsAgents.Classes
{
    public class DBManager
    {
        public static blockEntities context;
        public static blockEntities GetContext()
        {
            if (context == null)
                context = new blockEntities();
            return context;
        }
    }
}
