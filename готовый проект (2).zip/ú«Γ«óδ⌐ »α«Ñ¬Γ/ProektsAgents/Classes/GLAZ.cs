﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProektsAgents.Classes
{
    public class GLAZ
    {
        public string Title { get; set; }
        public List<GLAZ> TitleTwo ()
        {
            List<GLAZ> filya = new List<GLAZ>()
            {
                new GLAZ {Title="Нет сортировки"},
                new GLAZ {Title="По наименованию"},
                new GLAZ {Title="По приоритету"},
                new GLAZ {Title="По размеру скидки"}
            };
            return filya; 
        }
    }
}
