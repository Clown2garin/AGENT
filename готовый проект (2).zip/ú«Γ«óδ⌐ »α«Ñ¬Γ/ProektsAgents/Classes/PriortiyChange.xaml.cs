﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProektsAgents.Classes
{
    /// <summary>
    /// Логика взаимодействия для PriortiyChange.xaml
    /// </summary>
    public partial class PriortiyChange : Window
    {
        int Prioritet = 0;
        List<Agent> products;
        public PriortiyChange(List<Agent> selectedProducts)
        {
            InitializeComponent();
            products = selectedProducts;
            
        }

        private void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(CostBox.Text, out int Priority))
            {
                foreach (Agent product in products)
                {
                    if (Prioritet == 0)
                        product.Priority += Priority;
                    else
                        product.Priority -= Priority;
                }

                DBManager.GetContext().SaveChanges();

                MessageBox.Show("Данные внесены успешно!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            else
                MessageBox.Show("Значение введено не корректно. Поторите попытку!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            Prioritet = 0;
            Imya.Content = "Увеличить приоритет агентов на...";
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            Prioritet = 1;
            Imya.Content = "Уменьшить приоритет агентов на...";
        }
        void OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(IsGood);
        }
        private void OnPasting(object sender, DataObjectPastingEventArgs e)
        {
            var stringData = (string)e.DataObject.GetData(typeof(string));
            if (stringData == null || !stringData.All(IsGood))
                e.CancelCommand();
        }
        bool IsGood(char c)
        {
            if (c >= '0' && c <= '9')
                return true;
            if (c >= 'a' && c <= 'f')
                return true;
            if (c >= 'A' && c <= 'F')
                return true;
            return false;
        }
    }
}
