﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Reflection;
using System.Data.Entity.Infrastructure;
using ProektsAgents.Classes;

namespace ProektsAgents
{
    /// <summary>
    /// Логика взаимодействия для EditProductWindow.xaml
    /// </summary>
    public partial class EditProductWindow : Window
    {
        Agent currentAgent;
        bool isNewProduct;
        byte[] imageInBytes;
        string filePath;
        public EditProductWindow()
        {
            InitializeComponent();
            currentAgent = new Agent();
            DataContext = currentAgent;
            isNewProduct = true;
            Title = "Добавить продукт";
            DeleteProductBtn.Visibility = Visibility.Hidden;
            FillComboBox();
        }
        public EditProductWindow(Agent selectedProduct)
        {
            currentAgent = selectedProduct;
            DataContext = currentAgent;
            InitializeComponent();
            isNewProduct = false;
            Title = "Редактировать продукт";
            DeleteProductBtn.Visibility = Visibility.Visible;
            FillComboBox();
        }

        private void FillComboBox()
        {
            List<AgentType> productTypes = DBManager.GetContext().AgentType.ToList();
            ProductTypeCmb.ItemsSource = productTypes;
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private bool CheckIfArticleExist()
        {
            bool articleNotExist = true;
            List<Agent> products = DBManager.GetContext().Agent.ToList();
            foreach (var product in products)
                if (product.Phone.Contains(PhoneNumberBox.Text)
                    && product.ID != currentAgent.ID)
                {
                    articleNotExist = false;
                    break;
                }

            if (articleNotExist)
                return true;
            else
                return false;
        }

        private void UpdateData()
        {
            //обновление данных
            BindingManager.GetBindingExpression(AgentNameBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(ProductTypeCmb, ComboBox.SelectedItemProperty);
            BindingManager.GetBindingExpression(PhoneNumberBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(EmailNumberBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(INNBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(KPPBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(AddressBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(AddressBox_Copy, TextBox.TextProperty);
            BindingManager.GetBindingExpression(AddressBox_Copy1, TextBox.TextProperty);
            BindingManager.GetBindingExpression(AddressBox_Copy2, TextBox.TextProperty);
            BindingManager.GetBindingExpression(AddressBox_Copy3, TextBox.TextProperty);
            BindingManager.GetBindingExpression(DirectorBox, TextBox.TextProperty);
            BindingManager.GetBindingExpression(DirectorBox_Copy, TextBox.TextProperty);
            BindingManager.GetBindingExpression(DirectorBox_Copy1, TextBox.TextProperty);
            BindingManager.GetBindingExpression(PriorityBox, TextBox.TextProperty);
        }
        private void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
        {
            //проверка на пустоту компонентов
            if (!string.IsNullOrWhiteSpace(AgentNameBox.Text)
                 && !string.IsNullOrWhiteSpace(PhoneNumberBox.Text)
                 && !string.IsNullOrWhiteSpace(EmailNumberBox.Text)
                 && ProductTypeCmb.SelectedIndex != -1
                 && !string.IsNullOrWhiteSpace(INNBox.Text)
                 && !string.IsNullOrWhiteSpace(KPPBox.Text)
                 && !string.IsNullOrWhiteSpace(AddressBox.Text)
                 && !string.IsNullOrWhiteSpace(DirectorBox.Text)
                 && !string.IsNullOrWhiteSpace(PriorityBox.Text)
                 && !string.IsNullOrWhiteSpace(DirectorBox_Copy.Text)
                 && !string.IsNullOrWhiteSpace(DirectorBox_Copy1.Text)
                 && !string.IsNullOrWhiteSpace(AddressBox_Copy.Text)
                 && !string.IsNullOrWhiteSpace(AddressBox_Copy1.Text)
                 && !string.IsNullOrWhiteSpace(AddressBox_Copy2.Text)
                 && !string.IsNullOrWhiteSpace(AddressBox_Copy3.Text))
            {
                SaveImage();//метод сохранения изоображения 

                if (CheckIfArticleExist())
                {
                    if (isNewProduct)
                        DBManager.GetContext().Agent.Add(currentAgent);//добавление и редактирование агентов

                    UpdateData();
                    DBManager.GetContext().SaveChanges();//сохранения записей

                    MessageBox.Show("Данные внесены", "Информация",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    Close();
                }
                else
                    MessageBox.Show("Данный номер уже существует. Укажиет другой номер",
                        "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
                MessageBox.Show("Один или несколько полей не заполнены или введены не корректно. Повторите ввод!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void DeleteProductBtn_Click(object sender, RoutedEventArgs e)
        {
            //удаление агентов
            try
            {
                DBManager.GetContext().Agent.Remove(currentAgent);
                DBManager.GetContext().SaveChanges();

                MessageBox.Show("Данные удалены", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Close();
            }
            catch
            {

                MessageBox.Show("Удаление данного объекта невозможно", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                
            }
        }
        private void SaveImage()
        {
            //сохранения изоображений
            if (filePath == null && currentAgent.LogoImage == null)
            {
                var appDir = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var relativePath = @"picture.png";
                filePath = System.IO.Path.Combine(appDir, relativePath);
                imageInBytes = File.ReadAllBytes(filePath);
                currentAgent.LogoImage = imageInBytes;
            }
            else if (filePath != null)
            {
                imageInBytes = File.ReadAllBytes(filePath);
                currentAgent.LogoImage = imageInBytes;
            }
        }

        private void LoadImageBtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.CheckPathExists = true;
            openFileDialog.Title = "Загрузить изображение товара";
            openFileDialog.Filter = "Файлы изображений (*.bmp, *.jpg, *.png)|*.bmp;*.jpg;*.png";
            if (openFileDialog.ShowDialog() == true)
            {
                filePath = openFileDialog.FileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(filePath, UriKind.Relative);
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                ProductImage.Source = bitmap;
            }
        }

        private void WithoutWhiteSpace(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
                e.Handled = true;
        }
        private void OnlyDigit(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0))
                e.Handled = true;
        }

    }
}
