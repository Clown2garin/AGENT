﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProektsAgents.Classes;


namespace ProektsAgents
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        GLAZ glaz = new GLAZ();
        int numPages;
        int numEntriesPerPage = 10;
        int numCurrentPage = 1;
        int sortType;
        List<Agent> selectedProducts = new List<Agent>(); //получение списка агентов
        public MainWindow()
        {
            InitializeComponent();
            SortBox.SelectedIndex = 0;
            ViewProductList(GetProductList());
            FillComboBox();
            FiltresGLAZ(glaz.TitleTwo());
        }
        private void FiltresGLAZ(List<GLAZ> glaz)//Добавление фильтров в список (Cmb)
        {
            SortBox.ItemsSource = glaz;
            SortBox.SelectedIndex = 0;
        }
        private void FillComboBox()
        {
            //получение типов агентов в выпадающий список
            List<AgentType> productTypes = DBManager.GetContext().AgentType.ToList();
            AgentType productAll = new AgentType { Title = "Все типы" };
            productAll.Title = "Все типы";
            productTypes.Insert(0, productAll);
            ProductTypeCmb.ItemsSource = productTypes;
            ProductTypeCmb.SelectedIndex = 0;
        }
        private List<Agent> GetProductList()
        {
            //обращение к классу и подключение базы данных
            return DBManager.GetContext().Agent.ToList();
        }
        private void ViewProductList(List<Agent> agents)
        {
            //поиск через textbox по наименованию агента
            if (!string.IsNullOrWhiteSpace(SearchLineBox.Text))
            {
                agents = agents.Where(p => p.Title.ToLower().
                    Contains(SearchLineBox.Text.ToLower())).ToList();
            }
            //Фильтрация типов агентов
            if (ProductTypeCmb.SelectedIndex != 0)
            {
                AgentType selectedType = ProductTypeCmb.SelectedItem as AgentType;
                agents = agents.Where(x => x.AgentType == selectedType).ToList();
            }

            if (RbDown.IsChecked != false || RbUp.IsChecked != false)
                agents = SortProductList(agents);

            numPages = (int)Math.Ceiling((agents.Count * 1.0) / numEntriesPerPage);

            if (numCurrentPage > numPages)
                numCurrentPage = numPages;

            agents = agents.Skip((numCurrentPage - 1) * numEntriesPerPage).
                Take(numEntriesPerPage).ToList();

            ProductListBox.ItemsSource = agents;//вывод агентов
            CountPagesLb.Content = numCurrentPage + " / " + numPages;
        }
        private void RbStyle(int sortType)
        {
            RbUp.IsChecked = false;
            RbDown.IsChecked = false;
            if (sortType == 0)
            {
                RbUp.Visibility = Visibility.Hidden;
                RbDown.Visibility = Visibility.Hidden;
            }
            else 
            {
                RbUp.Visibility = Visibility.Visible;
                RbDown.Visibility = Visibility.Visible;
                if (sortType == 1)
                {
                    RbUp.Content = "А-Я";
                    RbDown.Content = "Я-А";
                }
                else
                {
                    RbUp.Content = "По возрастанию";
                    RbDown.Content = "По убыванию";
                }
            }
            ViewProductList(GetProductList());//Вывод данных
        }
        //Выбор фильтра и вывод результата
        private void SortBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            sortType = (int)SortBox.SelectedIndex;//Выбранный фильтр из списка
                RbStyle(sortType);
        }
        private List<Agent> SortProductList(List<Agent> products)//Фильтрация
        {
            if (RbDown != null || RbUp != null)
            {
                switch (sortType)
                {
                    case 1:
                       
                        if (RbUp.IsChecked == true) 
                            products = products.OrderBy(x => x.Title).ToList();
                        else if (RbDown.IsChecked == true)
                            products = products.OrderByDescending(x => x.Title).ToList(); 
                        break;
                    case 2:
                        if (RbUp.IsChecked == true) 
                            products = products.OrderBy(x => x.Priority).ToList();
                        else if (RbDown.IsChecked == true)
                            products = products.OrderByDescending(x => x.Priority).ToList(); 
                        break;
                    case 3:
                        if (RbUp.IsChecked == true)
                            products = products.OrderBy(x => x.Title).ToList();
                        else if (RbDown.IsChecked == true)
                            products = products.OrderByDescending(x => x.Title).ToList();
                        break;
                }
            }
            return products;
        }
        private void SearchLineBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            numCurrentPage = 1;
            ViewProductList(GetProductList());
        }
        private void ProductTypeCmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            numCurrentPage = 1;
            ViewProductList(GetProductList());
        }
        private void FirstPageBtn_Click(object sender, RoutedEventArgs e)
        {
            numCurrentPage = 1;
            ViewProductList(GetProductList());
        }

        private void PreviousPageBtn_Click(object sender, RoutedEventArgs e)
        {
            if (numCurrentPage != 1)
            {
                numCurrentPage--;
                ViewProductList(GetProductList());
            }
        }

        private void NextPageBtn_Click(object sender, RoutedEventArgs e)
        {
            if (numCurrentPage != numPages)
            {
                numCurrentPage++;
                ViewProductList(GetProductList());
            }
        }
        private void LastPageBtn_Click(object sender, RoutedEventArgs e)
        {
            numCurrentPage = numPages;
            ViewProductList(GetProductList());
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            new EditProductWindow().ShowDialog();
            ViewProductList(GetProductList());
        }
        private void EditProductBtn(object sender, RoutedEventArgs e)
        {
            new EditProductWindow((sender as Button).DataContext as Agent).ShowDialog();
            ViewProductList(GetProductList());
        }
        private void CostChange_Click(object sender, RoutedEventArgs e)
        {
            //Изменение приоритета агента
            if (selectedProducts.Count != 0)
            {
                new PriortiyChange(selectedProducts).ShowDialog();
                selectedProducts.Clear();
                ViewProductList(GetProductList());
            }
            else
                MessageBox.Show("Выберите один и более продуктов",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void SelectProductCheckBox_Click_1(object sender, RoutedEventArgs e)
        {
            if ((sender as CheckBox).IsChecked == true)
                selectedProducts.Add((sender as CheckBox).DataContext as Agent);
            else if ((sender as CheckBox).IsChecked == false)
                selectedProducts.Remove((sender as CheckBox).DataContext as Agent);
        }
        private void Close_btn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            ViewProductList(GetProductList());
        }
    }
}